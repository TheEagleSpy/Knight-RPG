import time
import random
import sys

healed_today = True

# Print text with delay
def Print(text, delay=0.02): #0.02
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

# Makes the game run (dont touch)
def start_game():
    # Sets up player data
    player_data = main_player()
    # Goes to next part of game one the previous is done
    start_prologue()
    start_story(player_data, settings)
    start_ending()

# Starting Player Stats
def main_player():
    player_data = {
        "max_health": 100,
        "health": 100,
        "strength": 0,
        "defence": 5,
        "gold": 0,
        "day": 0,
        "location": 'Forest',
        "weapon_equipped": 'Bronze Sword',
        "owned_weapons": ["Bronze Sword"]
    }
    return player_data

# Display player stats
def stat_display(player_data):
    print("\n-----Character Stats-----")
    print(f"Max Health: {player_data['max_health']}")
    print(f"Health: {player_data['health']}")
    print(f"Strength: {player_data['strength']}")
    print(f"Defence: {player_data['defence']}")
    print(f"Coins: {player_data['gold']}")
    print(f"Day: {player_data['day']}")
    print(f"Location: {player_data['location']}")
    print(f"Weapon: {player_data['weapon_equipped']}")
    print("\n-------------------------------------------------------------------------")

# Weapons Data
def weapons():
    weapons_data = {
        "swords": [
            {"name": "Bronze Sword", "damage": 8, "crit_chance": 2, "special": "None"},
            {"name": "Iron Sword", "damage": 16, "crit_chance": 5, "special": "None"},
            {"name": "Steel Sword", "damage": 35, "crit_chance": 7, "special": "None"},
            {"name": "Flame Sword", "damage": 70, "crit_chance": 10, "special": "None"},
            {"name": "Frost Sword", "damage": 85, "crit_chance": 35, "special": "None"},
            {"name": "Shadow Blade", "damage": 145, "crit_chance": 15, "special": "None"},
            {"name": "Dragon Blade", "damage": 450, "crit_chance": 0, "special": "None"},
        ],
        "bows": [
            {"name": "Hunting Bow", "damage": 25, "crit_chance": 3},
            {"name": "Elven Bow", "damage": 45, "crit_chance": 3},
            {"name": "Dragon Bow", "damage": 130, "crit_chance": 0},
        ],
        "spears": [
            {"name": "Eagle Spear", "damage": 35, "crit_chance": 100},
        ]
    }
    return weapons_data

# Sets up weapon data
weapons_data = weapons()

# Inventory
def inventory_display(player_data, weapons_data):  
    Print("\n-----Inventory-----")
    
    # Combine all weapon types into a single list
    all_weapons = []
    for category in ["swords", "bows", "spears"]:
        all_weapons.extend(weapons_data[category])
    
    owned_weapons = player_data['owned_weapons']
    
    # Display all weapons with ownership tags
    for index, weapon in enumerate(all_weapons, start=1):
        owned_tag = "(Owned)" if weapon['name'] in owned_weapons else "(Not Owned)"
        print(f"[{index}] {weapon['name']} {owned_tag}")
    
    # Allow player to select a weapon
    while True:
        try:
            weapon_select = input("\n[1-11] Select a weapon to view its stats\nPress 'r' to exit\nEnter: ").strip()
            
            if weapon_select.lower() == 'r':
                break
            
            weapon_select = int(weapon_select)  # Convert input to an integer
            
            if 1 <= weapon_select <= len(all_weapons):
                weapon = all_weapons[weapon_select - 1]
                view_weapon_stats(player_data, weapon)  # Pass the selected weapon only
                break
            else:
                print("Invalid Input, Please Try Again")
        except ValueError:
            print("\nInvalid input! Please enter a number or 'r' to exit.")

# View Weapon Stats In Inventory
def view_weapon_stats(player_data, weapon):
    Print(f"\n-----{weapon['name']} Stats-----")
    Print(f"Damage: {weapon['damage']}")
    Print(f"Critical Chance: {weapon['crit_chance']}%")
    if 'special' in weapon:
        Print(f"Enchantment: {weapon['special']}")
    
    equip = input("\nPress ENTER to equip this weapon or type 'r' to return:").lower().strip()
    if equip == "":
        if weapon['name'] in player_data['owned_weapons']:
            player_data['weapon_equipped'] = weapon['name']
            print(f"\nYou have equipped the {weapon['name']}!")
        else:
            print(f"\nYou do not own the {weapon['name']}.")
    elif equip == "r":
        return

# Access Weapon Damage
def get_equipped_weapon_damage(player_data):
    equipped_weapon_name = player_data['weapon_equipped']  # Get equipped weapon name
    weapons_data = weapons()  # Get all weapon data

    # Iterate through all weapon types (swords, bows, spears) to find the equipped weapon
    for weapon_type in weapons_data.values():
        for weapon in weapon_type:
            if weapon['name'] == equipped_weapon_name:
                return weapon['damage']  # Return the damage of the equipped weapon
    return None  # Return None if the equipped weapon is not found

# Displays Settings    
def settings_display():
    while True:
        print("\n-----Settings-----")    
        print(f"[1] Skip battles: {'True' if settings['skip_battles'] else 'False'}")
        print(f"[2] Debugging Mode: {'True' if settings['debugging'] else 'False'}")
        print("[3] Exit")
        
        try:
            settings_choice = int(input("\nEnter: "))
            if settings_choice == 1:
                skip_battles()
            elif settings_choice == 2:
                settings['debugging'] = 'True'
            elif settings_choice == 3:
                print("\n-------------------------------------------------------------------------")
                break
            else:
                print("Invalid option. Please try again.")
        except ValueError:
            print("Invalid input! Please enter a number.")

# Skip battle setting      
def skip_battles():
    settings["skip_battles"] = not settings["skip_battles"]
    skip_battles = "True" if settings["skip_battles"] else "False"

# List of settings        
settings = {
    "skip_battles": False,
    "debugging": False,
}

# Uses a health potion if allowed
def use_health_potion(player_data):
    possible_health = player_data['health'] - player_data['max_health']
    if player_data['location'] == 'Forest':
        health_potion = 50
        if possible_health >= health_potion:
            player_data['health'] += health_potion
            Print(f"You drank the potion and gained {health_potion}")
        else:
            print("error")
    elif player_data['location'] == 'Frozen_Peaks':
        health_potion = 75
        if possible_health >= health_potion:
            player_data['health'] += health_potion
            Print(f"You drank the potion and gained {health_potion}")
        else:
            print("error")
    elif player_data['location'] == "Swamplands":
        health_potion = 125
        if possible_health >= health_potion:
            player_data['health'] += health_potion
            Print(f"You drank the potion and gained {health_potion}")
        else:
            print("error")
    else:
        Print("You cannot use health potions here")

# -- Forest -- #

# Forest Enemies list
def enemy_data_forest():
    # Easy
    rock = {"name": "Pet Rock", "health": 5, "strength": -5, "gold": 5}
    weak_goblin = {"name": "Weak Goblin", "health": 7, "strength": 3, "gold": 25}
    strong_goblin = {"name": "Strong Goblin", "health": 19, "strength": 7,  "gold": 40}
    orc = {"name": "Orc", "health": 30, "strength": 8, "gold": 20}
    weak_bandit = {"name": "Weak Bandit", "health": 50, "strength": 5, "gold": 35}
    skeleton = {"name": "Skeleton", "health": 20, "strength": 6, "gold": 5}
    wild_dog = {"name": "Wild Dog", "health": 35, "strength": 9, "gold": 5}
    strong_orc = {"name": "Strong Orc", "health": 35, "strength": 13, "gold": 30}
    treasure_chest = {"name": "Treasure Chest", "health": 5, "strength": -5, "gold": 150}
    # Medium
    fly = {"name": "Fly", "health": 10, "strength": 90, "gold": 30}
    albert = {"name": "Albert (homeless)", "health": 50, "strength": 6, "gold": 5}
    defensive_bird = {"name": "Defensive Bird", "health": 20, "strength": 10, "gold": 10}
    wolf = {"name": "Wolf", "health": 40, "strength": 6, "gold": 15}
    cursed_spirit = {"name": "Cursed Spirit", "health": 35, "strength": 15, "gold": 30}
    tree_ent = {"name": "Tree Ent", "health": 65, "strength": 8, "gold": 120}
    sword_skeleton = {"name": "Sword Skeleton", "health": 20, "strength": 20, "gold": 50}
    # Hard
    giant_orc = {"name": "Giant Orc", "health": 75, "strength": 13, "gold": 50}
    metal_skeleton = {"name": "Metal Skeleton", "health": 60, "strength": 8, "gold": 60}
    strong_bandit = {"name": "Strong Bandit", "health": 100, "strength": 9, "gold": 85}
    distorted_figure = {"name": "Distorted Figure", "health": 20, "strength": 45, "gold": 65}
    # Boss
    howler = {"name": "Howler", "health": 300, "strength": 25, "gold": 300}

    enemy_type = random.random()
    if enemy_type <= 0.60: # Easy Enemies (60%)
        random_enemy = random.random()
        if random_enemy <= 0.05: # 5%
            current_enemy = rock
        elif random_enemy <= 0.20: # 15%
            current_enemy = weak_goblin
        elif random_enemy <= 0.35: # 15% 
            current_enemy = strong_goblin
        elif random_enemy <= 0.45: # 10%
            current_enemy = orc
        elif random_enemy <= 0.55: # 10%
            current_enemy = weak_bandit
        elif random_enemy <= 0.70: # 15%
            current_enemy = skeleton
        elif random_enemy <= 0.80: # 10%
            current_enemy = wild_dog
        elif random_enemy <= 0.95: # 15%
            current_enemy = strong_orc
        else:
            current_enemy = treasure_chest
    elif enemy_type <= 0.90: # Medium Enemies (25%)
        random_enemy = random.random()
        if random_enemy <= 0.05: # 5%
            current_enemy = fly
        elif random_enemy <= 0.10: # 5%
            current_enemy = albert
        elif random_enemy <= 0.40: # 30%
            current_enemy = defensive_bird
        elif random_enemy <= 0.60: # 20%
            current_enemy = wolf
        elif random_enemy <= 0.85: # 25%
            current_enemy = cursed_spirit
        elif random_enemy <= 0.95: # 10%
            current_enemy = tree_ent
        else:
            current_enemy = sword_skeleton # 5%
    else: # Hard Enemies (10%)
        random_enemy = random.random()
        if random_enemy <= 0.20: # 20%
            current_enemy = giant_orc
        elif random_enemy < 0.60: # 30%
            current_enemy = metal_skeleton
        elif random_enemy < 0.85: # 25%
            current_enemy = strong_bandit
        else: # 15%
            current_enemy = distorted_figure

    return current_enemy

# Player explores forest
def explore_forest(player_data):
    
    exploration_time = random.randint(3, 6) # How many events the player in encounter
    
    while True:
        print(f"Time left exploring {exploration_time}") # DEBUGGING
        if exploration_time > 0:
            exploration = random.random() # What event the player will encounter
            print(f"Exploration value: {exploration}") # DEBUGGING
            
            # Player comes back with nothing
            if exploration < 0.35:
                Print("\nYou came back empty handed")
                exploration_time -= 1
                
            # Player finds a shrine
            elif exploration < 0.45:
                Print("\nYou uncover a mysterious shrine!")
                Print("[1] Investigate [2] Leave")
                action = input("Enter: ")
                if action == '1':
                    shrine_luck = random.random() # What happens when the player touches the shrine
                    if shrine_luck < 0.33:
                        Print("\nYou feel a warm sensation cover your body +35 Health +5 Max Health")
                        player_data['max_health'] += 5
                        player_data['health'] += 35
                        exploration_time -= 1
                    elif shrine_luck < 0.66:
                        Print("\nYou feel a figure touch your shoulder...")
                        time.sleep(3)
                        Print("\nBefore you can catch a glimpse, it disapears into the trees and you hope that nothing bad happend")
                        player_data['max_health'] -= 10
                        exploration_time -= 1
                    else:
                        Print("\nYou feel lucky +30 Gold")
                        player_data['gold'] += 30
                        exploration_time -= 1
                elif action == '2':
                    Print("\nYou leave the shrine and continue on")
                    exploration_time -= 1
                    
            # Player walks into a trap
            elif exploration < 0.55:
                Print("\nYou walked into a trap!")
                trap_luck = random.random()
                if trap_luck < 0.40:
                    Print("You fell into a hole and took 10 Damage")
                    player_data['health'] -= 10
                    exploration_time -= 1
                elif trap_luck < 0.80:
                    Print("You got hit by a falling log and took 30 Damage")
                    player_data['health'] -= 30
                    exploration_time -= 1
                else:
                    Print("Haha just kidding there was no trap there but you did find an apple + 5 Health")
                    player_data['health'] += 5
                    exploration_time -= 1
                    
            # Player finds an enemy
            elif exploration < 0.90:
                battle(player_data)
                exploration_time -= 1
            # Player encounters the merchant
            
            else:
                forest_merchant(player_data)
                exploration_time -= 1                   
        else:
            player_data['day'] += 1
            break

# Forest Merchant Encounter
def forest_merchant(player_data):
    print("\n-------------------------------------------------------------------------")
    while True:
        Print("\n[Merchant] Hello I am a merchant what would you like to buy?")
        Print(f"\nYou have {player_data['gold']} Gold")
        action = input("\n-----Swords-----\n\n[1] Iron Sword --75 Gold--\n[2] Steel Sword --200 Gold--\n\n-----Bows-----\n\n[3] Hunting bow --200 Gold--\n\n-----Potions/Crystals-----\n\n[4] Health Potion --50 Gold--\n[5] Health Crystal --300 Gold--\n\n[r] Exit ")
        if action == '1':
            if player_data['gold'] >= 75:
                confirmation = input("Press ENTER to confirm or ' r ' to Return ")
                if confirmation == '':
                    if "Iron Sword" in player_data['owned_weapons']:
                        Print("\n[Merchant] You dont need another Iron Sword I see one on your back")
                    else:
                        Print("\n[Knight] I would like an ☆ Iron Sword ☆ Please")
                        time.sleep(1)
                        Print("\n-100 Gold")
                        player_data['gold'] -= 75
                        player_data['owned_weapons'].append("Iron Sword")
                        time.sleep(1)
                        Print("\n[Merchant] Here you go young one")
                else:
                    pass    
        elif action == '2':
            if player_data['gold'] >= 200:
                confirmation = input("Press ENTER to confirm or ' r ' to Return ")
                if confirmation == '':
                    if "Steel Sword" in player_data['owned_weapons']:
                        Print("\n[Merchant] You dont need another Steel Sword I see one on your back")
                    else:
                        Print("\n[Knight] Can I have a ☆ Steel Sword ☆ Please")
                        Print("\n-200 Gold")
                        player_data['gold'] -= 200
                        player_data['owned_weapons'].append("Steel Sword")
                        print(player_data["owned_weapons"])
                        time.sleep(0.5)
                        Print("\n[Merchant] I believe you can kill anything with this!")
                else:
                    pass
        elif action == '3':
            if player_data['gold'] >= 200:
                confirmation = input("Press ENTER to confirm or ' r ' to Return ")
                if confirmation == '':
                    if "Hunting Bow" in player_data['owned_weapons']:
                        Print("You already own this")
                    else:
                        Print("\n[Knight] Can I have a ☆ Hunting Bow ☆ Please")
                        time.sleep(0.5)
                        Print("\n[Merchant] Thats a good choice! Hope it does you well")
                        player_data['gold'] -= 200
                        player_data['owned_weapons'].append("Hunting Bow")
                        time.sleep(0.5)
                        Print("[Merchant] Good luck")
                else:
                    pass
        elif action == '4':
            if player_data['gold'] >= 50:
                confirmation = input("Press ENTER to confirm or ' r ' to Return ")
                if confirmation == '':
                    possible_health = player_data['max_health'] - player_data['health']
                    if possible_health > 50:
                        use_health_potion(player_data)
                else:
                    pass
        elif action == '5':
            if player_data['gold'] >= 300:
                confirmation = input("Press ENTER to confirm or ' r ' to Return ")
                if confirmation == '':
                    Print("You stared into the crystal and gained 20 MAX health")
                    player_data['max_health'] += 20
                    player_data['health'] += 20   
                else:
                    pass
        elif action == 'r':
            print("\n-------------------------------------------------------------------------")
            break
        else:
            Print("Please Enter a valid option") 

# -- Frozen Peaks -- #

# Frozen Peaks Enemies list
def enemy_data_frozen_peaks():
    frost_orc = {"name": "Frost Orc", "health": 45, "strength": 13, "gold": 20}
    ice_wraith = {"name": "Ice Wraith", "health": 30, "strength": 25, "gold": 25}
    snow_hunter = {"name": "Snow Hunter", "health": 75, "strength": 20, "gold": 35}
    shade = {"name": "Shade", "health": 1, "strength": 130, "gold": 100}
    golem = {"name": "Golem", "health": 300, "strength": 8, "gold": 75}
    frost_wraith = {"name": "Frost Wraith", "health": 50, "strength": 30, "gold": 40}
    
    random_enemy = random.random()
    if random_enemy <= 0.35:
        current_enemy = frost_orc # 35%
    elif random_enemy <= 0.6:
        current_enemy = ice_wraith # 25%
    elif random_enemy <= 0.75:
        current_enemy = snow_hunter # 15%
    elif random_enemy <= 0.85:
        current_enemy = shade # 10%
    elif random_enemy <= 0.95:
        current_enemy = golem # 10%
    else:
        current_enemy = frost_wraith # 5%
        
    return current_enemy

# Player explores frozen peaks
def explore_frozen_peaks(player_data):
    exploration_time = random.randint(3, 6) # How many events the player in encounter
    while True:
        print(f"Time left exploring {exploration_time}") # DEBUGGING
        if exploration_time > 0:
            exploration = random.random() # What event the player will encounter
            print(f"Exploration value: {exploration}") # DEBUGGING
            # Player comes back with nothing
            if exploration < 0.35:
                Print("\nYou came back empty handed")
                exploration_time -= 1
            # Player finds a shrine
            elif exploration < 0.45:
                Print("\nYou uncover a mysterious shrine!")
                Print("[1] Investigate [2] Leave")
                action = input("Enter: ")
                if action == '1':
                    shrine_luck = random.random() # What happens when the player touches the shrine
                    if shrine_luck < 0.33:
                        Print("\nYou feel a warm sensation cover your body +35 Health +5 Max Health")
                        player_data['max_health'] += 5
                        player_data['health'] += 35
                        exploration_time -= 1
                    elif shrine_luck < 0.66:
                        Print("\nYou feel a figure touch your shoulder...")
                        time.sleep(3)
                        Print("\nBefore you can catch a glimpse, it disapears into the trees and you hope that nothing bad happend")
                        player_data['max_health'] -= 10
                        exploration_time -= 1
                    else:
                        Print("\nYou feel lucky +30 Gold")
                        player_data['gold'] += 30
                        exploration_time -= 1
                elif action == '2':
                    Print("\nYou leave the shrine and continue on")
                    exploration_time -= 1
            # Player walks into a trap
            elif exploration < 0.55:
                Print("\nYou walked into a trap!")
                trap_luck = random.random()
                if trap_luck < 0.40:
                    Print("\nYou fell into a hole and took 10 Damage")
                    player_data['health'] -= 10
                    exploration_time -= 1
                elif trap_luck < 0.80:
                    Print("\nYou got hit by a falling log and took 30 Damage")
                    player_data['health'] -= 30
                    exploration_time -= 1
                else:
                    Print("\nHaha just kidding there was no trap there but you did find an apple + 5 Health")
                    player_data['health'] += 5
                    exploration_time -= 1
            # Player finds an enemy
            elif exploration < 0.90:
                battle(player_data)
                exploration_time -= 1
            # Player encounters the merchant
            else:
                frozen_peaks_merchant(player_data)
                exploration_time -= 1                   
        else:
            player_data['day'] += 1
            break

# Forest Merchant Encounter
def frozen_peaks_merchant(player_data):
    while True:
        Print("\n[Merchant] Hello I am a merchant what would you like to buy?")
        Print(f"\nYou have {player_data['gold']} Gold")
        action = input("\n-----Swords-----\n\n[1] Steel Sword --300 Gold--\n[2] Flame Sword --650 Gold--\n\n-----Spears-----\n\n[3] Eagle Spear --650 Gold--\n\n-----Potions/Crystals-----\n\n[4] Health Potion --100 Gold--\n[5] Health Crystal --600 Gold--\n\n[r] Exit ")
        if action == '1':
            if player_data['gold'] >= 300:
                confirmation = input("Press ENTER to confirm or ' r ' to Return ")
                if confirmation == '':
                    if "Steel Sword" in player_data['owned_weapons']:
                        Print("\n[Merchant] You dont need another Steel Sword I see one on your back!")
                    else:
                        Print("\n[Knight] I would like an ☆ Steel Sword ☆  Please")
                        time.sleep(0.5)
                        Print("\n-300 Gold")
                        player_data['gold'] -= 300
                        player_data['owned_weapons'].append("Steel Sword")
                        time.sleep(0.5)
                        Print("\n[Merchant] Here you go young one")
                else:
                    pass    
        elif action == '2':
            if player_data['gold'] >= 650:
                confirmation = input("Press ENTER to confirm or ' r ' to Return ")
                if confirmation == '':
                    if "Flame Sword" in player_data['owned_weapons']:
                        Print("\n[Merchant] You dont need another Flame Sword I see one on your back!")
                    else:
                        Print("\n[Knight] I would like an ☆ Flame Sword ☆  Please")
                        player_data['gold'] -= 650
                        player_data['owned_weapons'].append("Flame Sword")
                else:
                    pass
        elif action == '3':
            if player_data['gold'] >= 650:
                confirmation = input("Press ENTER to confirm or ' r ' to Return ")
                if confirmation == '':
                    if "Hunting Bow" in player_data['owned_weapons']:
                        Print("You already own this")
                    else:
                        player_data['gold'] -= 650
                        player_data['owned_weapons'].append("Hunting Bow ")
                else:
                    pass
        elif action == '4':
            if player_data['gold'] >= 150:
                confirmation = input("Press ENTER to confirm or ' r ' to Return ")
                if confirmation == '':
                    possible_health = player_data['max_health'] - player_data['health']
                    if possible_health > 150:
                        use_health_potion(player_data)
                else:
                    pass
        elif action == '5':
            if player_data['gold'] >= 600:
                confirmation = input("Press ENTER to confirm or ' r ' to Return ")
                if confirmation == '':
                    Print("You stared into the crystal and gained 35 MAX health")
                    player_data['max_health'] += 35
                    player_data['health'] += 35   
                else:
                    pass
        elif action == 'r':
            break
        else:
            Print("Please Enter a valid option") 
            
# -- Swamplands -- #

# Swamplands Enemies list
def enemy_data_swamplands():
    leech = {"name": "Leech", "health": 60, "strength": 15, "gold": 15}
    cursed_lilypad = {"name": "Cursed Lillypad", "health": 135, "strength": 39, "gold": 50}
    witch = {"name": "Witch", "health": 130, "strength": 75, "gold": 70}
    arc = {"name": "ARC", "health": 165, "strength": 55, "gold": 80}
    rotwood = {"name": "Rotwood", "health": 250, "strength": 200, "gold": 100}
    zombie = {"name": "Zombie", "health": 300, "strength": 17, "gold": 90}
    skin_walker = {"name": "Skin Walker", "health": 133, "strength": 300, "gold": 150}
    devil = {"name": "Devil", "health": 10000, "strength": 100, "gold": 1000}
    
    random_enemy = random.random()
    if random_enemy < 0.20:
        current_enemy = leech # 20%
    elif random_enemy < 0.40:
        current_enemy = cursed_lilypad # 20%
    elif random_enemy < 0.60:
        current_enemy = witch # 20%
    elif random_enemy < 0.75:
        current_enemy = arc # 15%
    elif random_enemy < 0.86:
        current_enemy = rotwood # 11%
    elif random_enemy < 0.93:
        current_enemy = zombie # 7%
    elif random_enemy < 0.97:
        current_enemy = skin_walker # 4%
    else:
        current_enemy = devil # 3%
        
    return current_enemy

# Player Explores Swamplands
def explore_swamplands(player_data):
    exploration_time = random.randint(3, 6) # How many events the player in encounter
    while True:
        print(f"Time left exploring {exploration_time}") # DEBUGGING
        if exploration_time > 0:
            exploration = random.random() # What event the player will encounter
            print(f"Exploration value: {exploration}") # DEBUGGING
            # Player comes back with nothing
            if exploration < 0.35:
                Print("\nYou came back empty handed")
                exploration_time -= 1
            # Player finds a shrine
            elif exploration < 0.45:
                Print("\nYou uncover a mysterious shrine!")
                Print("[1] Investigate [2] Leave")
                action = input("Enter: ")
                if action == '1':
                    shrine_luck = random.random() # What happens when the player touches the shrine
                    if shrine_luck < 0.33:
                        Print("\nYou feel a warm sensation cover your body +35 Health +5 Max Health")
                        player_data['max_health'] += 5
                        player_data['health'] += 35
                        exploration_time -= 1
                    elif shrine_luck < 0.66:
                        Print("\nYou feel a figure touch your shoulder...")
                        time.sleep(3)
                        Print("\nBefore you can catch a glimpse, it disapears into the trees and you hope that nothing bad happend")
                        player_data['max_health'] -= 10
                        exploration_time -= 1
                    else:
                        Print("\nYou feel lucky +30 Gold")
                        player_data['gold'] += 30
                        exploration_time -= 1
                elif action == '2':
                    Print("\nYou leave the shrine and continue on")
                    exploration_time -= 1
            # Player walks into a trap
            elif exploration < 0.55:
                Print("\nYou walked into a trap!")
                trap_luck = random.random()
                if trap_luck < 0.40:
                    Print("\nYou fell into a hole and took 10 Damage")
                    player_data['health'] -= 10
                    exploration_time -= 1
                elif trap_luck < 0.80:
                    Print("\nYou got hit by a falling log and took 30 Damage")
                    player_data['health'] -= 30
                    exploration_time -= 1
                else:
                    Print("\nHaha just kidding there was no trap there but you did find an apple + 5 Health")
                    player_data['health'] += 5
                    exploration_time -= 1
            # Player finds an enemy
            elif exploration < 0.90:
                battle(player_data)
                exploration_time -= 1
            # Player encounters the merchant
            else:
                swamplands_merchant(player_data)
                exploration_time -= 1                   
        else:
            player_data['day'] += 1
            break

# Forest Merchant Encounter
def swamplands_merchant(player_data):
    while True:
        Print("\n[Merchant] Hello I am a merchant what would you like to buy?")
        Print(f"\nYou have {player_data['gold']} Gold")
        action = input("\n-----Swords-----\n\n[1] Steel Sword --300 Gold--\n[2] Flame Sword --650 Gold--\n\n-----Spears-----\n\n[3] Eagle Spear --650 Gold--\n\n-----Potions/Crystals-----\n\n[4] Health Potion --100 Gold--\n[5] Health Crystal --600 Gold--\n\n[r] Exit ")
        if action == '1':
            if player_data['gold'] >= 300:
                confirmation = input("Press ENTER to confirm or ' r ' to Return ")
                if confirmation == '':
                    if "Steel Sword" in player_data['owned_weapons']:
                        Print("\n[Merchant] You dont need another Steel Sword I see one on your back!")
                    else:
                        Print("\n[Knight] I would like an ☆ Steel Sword ☆  Please")
                        time.sleep(0.5)
                        Print("\n-300 Gold")
                        player_data['gold'] -= 300
                        player_data['owned_weapons'].append("Steel Sword")
                        time.sleep(0.5)
                        Print("\n[Merchant] Here you go young one")
                else:
                    pass    
        elif action == '2':
            if player_data['gold'] >= 650:
                confirmation = input("Press ENTER to confirm or ' r ' to Return ")
                if confirmation == '':
                    if "Flame Sword" in player_data['owned_weapons']:
                        Print("\n[Merchant] You dont need another Flame Sword I see one on your back!")
                    else:
                        Print("\n[Knight] I would like an ☆ Flame Sword ☆  Please")
                        player_data['gold'] -= 650
                        player_data['owned_weapons'].append("Flame Sword")
                else:
                    pass
        elif action == '3':
            if player_data['gold'] >= 650:
                confirmation = input("Press ENTER to confirm or ' r ' to Return ")
                if confirmation == '':
                    if "Hunting Bow" in player_data['owned_weapons']:
                        Print("You already own this")
                    else:
                        player_data['gold'] -= 650
                        player_data['owned_weapons'].append("Hunting Bow ")
                else:
                    pass
        elif action == '4':
            if player_data['gold'] >= 150:
                confirmation = input("Press ENTER to confirm or ' r ' to Return ")
                if confirmation == '':
                    possible_health = player_data['max_health'] - player_data['health']
                    if possible_health > 150:
                        use_health_potion(player_data)
                else:
                    pass
        elif action == '5':
            if player_data['gold'] >= 600:
                confirmation = input("Press ENTER to confirm or ' r ' to Return ")
                if confirmation == '':
                    Print("You stared into the crystal and gained 35 MAX health")
                    player_data['max_health'] += 35
                    player_data['health'] += 35   
                else:
                    pass
        elif action == 'r':
            break
        else:
            Print("Please Enter a valid option") 

# -- Rest Of Game -- #
      
# Plays Queen and knight yapping and fake loading
def start_prologue():
    Print("-----Prologue-----\n")
    Print("[Queen] You have been tasked with slaying the dragon that dwells in the Caves of Hulpha. This will not be an easy quest, as you must journey through the Frozen Peaks, Swamplands, and the village of Klare.\n[Queen] Good luck, my brave knight. My kingdom and I will await your safe return.\n")
    Print("[Knight] I accept this quest, my queen. For your safety and for the honor of the kingdom, I shall see the beast slain. The Frozen Peaks, the Swamplands, and the villagers of Klare will not stop me. I will come back safely.\n")
    Print("[Queen] Brave words, good knight, but strength alone will not defeat the dragon. You must use intelligence, patience, and follow your heart.\n[Queen] Go brave knight and may the gods be on your side ❤️\n")
    start_game = input("Press ENTER to begin ")
    
    if start_game == '':
        print("\n-------------------------------------------------------------------------")
        Print("\nLoading enemy_data (enemy_stats)...")
        time.sleep(random.uniform(0.2, 1.9))
        Print("Loading player_data (player_stats)...")
        time.sleep(random.uniform(1.3, 3.5))
        Print("Loading random variables...")
        time.sleep(random.uniform(0.2, 0.5))
        Print("Finishing up...")
        time.sleep(random.uniform(0.3, 0.7))
        Print("Loading Complete!")
        print("\n-------------------------------------------------------------------------")
    elif start_game == 'egg':
        pass
    else:
        print("\n-------------------------------------------------------------------------")
        Print("\nLoading enemy_data (enemy_stats)...")
        time.sleep(random.uniform(0.5, 1.7))
        Print("Loading player_data (player_stats)...")
        time.sleep(random.uniform(1.0, 2.1))
        Print("Loading random variables...")
        time.sleep(random.uniform(1.5, 2.5))
        Print("Finishing up...")
        time.sleep(random.uniform(1.1, 3.0))
        Print("Loading Complete")
        print("\n-------------------------------------------------------------------------")

# Enemy Battle
def battle(player_data):
    if player_data['location'] == 'Forest':
        current_enemy = enemy_data_forest()
    elif player_data['location'] == 'Frozen Peaks':
        current_enemy = enemy_data_frozen_peaks()
    elif player_data['location'] == 'Swamplands':
        current_enemy = enemy_data_swamplands()
    else:
        pass
    Print("\n-----Enemy Battle-----")
    Print(f"While exploring around the trees you encountered a {current_enemy['name']}")
    true_damage = get_equipped_weapon_damage(player_data) + player_data['strength']
    enemy_damage = current_enemy['strength'] - player_data['defence']
    # Fight loop
    while player_data['health'] > 0 and current_enemy['health'] > 0:
        # Player Attacks
        player_damage = random.randint(max(1, true_damage -3), true_damage + 5)
        current_enemy['health'] -= player_damage
        Print(f"\nYou attacked the {current_enemy['name']} and dealt {player_damage} damage! Health remaining: {current_enemy['health']}")
        
        if current_enemy['health'] <= 0:
            Print(f"\nYou defeated the {current_enemy['name']}!")
            player_data['gold'] += current_enemy['gold']
            Print(f"You recieved {current_enemy['gold']} gold")
            break
        
        #Enemy Attacks
        enemy_damage = random.randint(max(1, current_enemy['strength'] - 3), current_enemy['strength'] + 5)

        player_data['health'] -= enemy_damage
        Print(f"The {current_enemy['name']} did {enemy_damage} damage! Health remaining: {player_data['health']}")
        
        if player_data['health'] <= 0:
            Print("You have unfortunatly died, failing to slay the dragon and save the kingdom")
            sys.exit()
        
    if player_data['health'] > 0:
        Print("\n[Knight] Ha! No enemy shall stop me from slaying the dragon!")
    else:
        pass

# Main game loop
def start_story(player_data, settings):
    Print("\n-----Main Game-----")
    Print("\nYou leave the castle and head out to the forest and setup a camp")
    stat_display(player_data)
    
    while True:
        if player_data['health'] > player_data['max_health']:
            player_data['health'] = player_data['max_health']
        print("\n[1] Explore\n[2] Rest\n[3] Check Stats\n[4] View Inventory\n[5] Settings\n[6] Help\n[7] Update log")
        action = input("Enter: ")
        if action == '1':
            # If the player is in the forest
            if player_data['location'] == 'Forest':
                explore_forest(player_data) 
                global healed_today
                healed_today = False
            # If the player is in the frozen peaks        
            elif player_data['location'] == 'Frozen Peaks':
                explore_frozen_peaks(player_data)
                healed_today = False
            # If the player is in the swamplands
            elif player_data['location'] == 'Swamplands':
                explore_swamplands(player_data)
                healed_today = False
        elif action == '2':
            if healed_today == False:
                player_data['health'] = min(player_data['max_health'], player_data['health'] + 30)
                player_data['max_health'] += 5
                Print("\n[Knight] I shall sit down to regain my strength (+30 Health, +5 Max Health)")
                healed_today = True
            else:
                Print("\n[Knight] I have too much energy to sit down right now")
        elif action == '3':
            # Display stats
            stat_display(player_data)
        elif action == '4':
            # Display inventory
            inventory_display(player_data, weapons_data)
        elif action == '5':
            # Display settings
            settings_display()
        elif action == '6':
            # Help menu
            Print("\n-----Help Menu-----")
            Print("\n[1] How to win\n[2] Progessing through levels\n[3] What are enchants?\n[4] Enchant list\n[5] How do I spend my gold?\n[6] Recommended stats for bosses")
            action = input("Enter: ")
            if action == '1':
                Print("\nTo win you must go through the 4 zones (forest, frozen peaks, swamplands and the town) then defeat the dragon")
            elif action == '2':
                Print("\nTo progress to the next area you must defeat the boss of the current area you are in")
            elif action == '3':
                Print("\nEnchants are applied to the current weapon you have equipped and are saved when swapping weapons")
            elif action == '4':
                Print("Strenght 1 +15% Damage\nStrength 2 +45% Damage\nStrength 3 +100% Damage\nPrecision 1 +10% Crit Chance\nPrecision 2 +25% Crit Chance")
            elif action == '5':
                Print("\nYou can spend gold at the merchant which has about a 20% chance of appearing each day")
            elif action == '6':
                Print("\nHowler: 180 Health 40 Damage\nBigfoot: 500 Health 80 Damage\nHeadwitch: 1200 Health 180 Damage\nBaron: 2000 Health 250 Damage\nDragon: ???")
        elif action == '7':
            # Update log
            Print("\n-----Current Version: V2-----")
            Print("\n- Added a debugging menu")
            Print("- Added a help menu")
            Print("- Remove Levels")
            Print("- Added wayyy more Forest enemies")
            Print("- Balance changes")
            Print("- More dialogue")
            Print("- Changed starting prologue")
            Print("- Added some more dividers between parts of the game")
            print("\n-------------------------------------------------------------------------")
        elif action == '8':
            # Debuging Menu
            if settings['debugging'] == 'True':
                print("\n---Debugging Menu---")
                print("\n[1] Set Max Health\n[2] Set Health\n[3] Set Strength\n[4] Set Defence\n[5] Set Gold\n[6] Set Location\n[7] Set Current Weapon")
                action = input("Enter: ")
                if action == '1':
                    player_data['max_health'] = int(input("Set Max Health: "))
                elif action == '2':
                    player_data['health'] = int(input("Set Health: "))
                elif action == '3':
                    player_data['strength'] = int(input("Set Strength: "))
                elif action == '4':
                    player_data['defence'] = int(input("Set Defence: "))
                elif action == '5':
                    player_data['gold'] = int(input("Set Gold: "))
                elif action == '6':
                    player_data['location'] = (input("Set Current Location: "))
                elif action == '7':
                    player_data['weapon_equipped'] = (input("Set Current Weapon: "))
            else:
              print("That is not a valid input")  
        else:
            print("That is not a valid input")

# Ending dialog      
def start_ending():
    Print("You made it back safely and won!")

start_game()
